package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utility.Constants;

public class StepDef {
	WebDriver driver;

	@Given("User Launch Chrome browser")
	public void user_Launch_Chrome_browser() {
		
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}

	@When("User opens URL {string}")
	public void user_opens_URL(String appURL) {
		
		
		System.out.println("fetch value from : " + Constants.nop_app_qa);
		driver.get(appURL);
		
	}

	@When("User enters Email as {string} and Password as {string}")
	public void user_enters_Email_as_and_Password_as(String email, String pass) {
		
		driver.findElement(By.cssSelector("input#Email")).clear();;
		driver.findElement(By.cssSelector("input#Email")).sendKeys(email);
		
		
		driver.findElement(By.cssSelector("input#Password")).clear();;
		driver.findElement(By.cssSelector("input#Password")).sendKeys(pass);
		
	}

	@When("Click on Login")
	public void click_on_Login() {
		
		driver.findElement(By.tagName("button")).click();
		
	}

	@Then("Page Title should be {string}")
	public void page_Title_should_be(String expetedTitle) throws Exception {
		
		Thread.sleep(3000);
		Assert.assertEquals(driver.getTitle(), expetedTitle);
		
	}

	@When("User click on Log out link")
	public void user_click_on_Log_out_link() {
		
		driver.findElement(By.partialLinkText("Logo")).click();
		
	}

	@Then("close browser")
	public void close_browser() throws Exception {
		
		
		Thread.sleep(7000);
		driver.close();
		driver.quit();
		
	}

}
