package testRun;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

//Cucumber - junit and testNG both
//RunWith ---- junit




@CucumberOptions(
		
		
						features = ".\\IBM_Feature_batch1\\", 
						glue = "steps",
						
						tags = "@ibm_regression",
						
						plugin = { 	
								
									"pretty", 
									"html:target/ibm_CucumberReport.html" 
						
									}
				
		
				)







public class TestRunner extends AbstractTestNGCucumberTests{

	
	
}
